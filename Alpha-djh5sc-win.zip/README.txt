Controls:

Jump = Space/A Button
Rewind = R/Left Trigger
Stop = Left Control/B Button
Fast-Forward = F/Right Trigger
Restart = Backspace/Back
